"""Customer Churn Analysis: cleaning, EDA charts, model training, export."""
import json, os, sys, urllib.request, joblib, numpy as np, pandas as pd, sklearn
os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.makedirs("models", exist_ok=True); os.makedirs("charts", exist_ok=True); os.makedirs("data", exist_ok=True)
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix, roc_curve)

sns.set_theme(style="whitegrid")
CSV = "data/Telco-Customer-Churn.csv"
if not os.path.exists(CSV):
    print("Dataset not found, downloading...")
    urllib.request.urlretrieve("https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv", CSV)
df = pd.read_csv(CSV)
print("Raw shape:", df.shape)
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
print("Blank TotalCharges:", df["TotalCharges"].isna().sum())
df = df.dropna(subset=["TotalCharges"]).drop_duplicates("customerID").copy()
df["SeniorCitizen"] = df["SeniorCitizen"].map({0: "No", 1: "Yes"})
y = (df["Churn"] == "Yes").astype(int)
overall = y.mean() * 100
print(f"Clean rows: {len(df)}  churn rate: {overall:.2f}%")

# ---------- EDA charts ----------
df["ChurnFlag"] = y
def rate_chart(col, fname, order=None):
    r = df.groupby(col)["ChurnFlag"].mean().mul(100)
    if order: r = r.reindex(order)
    ax = r.plot(kind="bar", color="#2E75B6", figsize=(6, 3.6), rot=20)
    for p in ax.patches:
        ax.annotate(f"{p.get_height():.1f}%", (p.get_x()+p.get_width()/2, p.get_height()), ha="center", va="bottom")
    ax.axhline(overall, color="red", ls="--"); ax.set_ylabel("Churn rate (%)"); ax.set_title(f"Churn rate by {col}")
    plt.tight_layout(); plt.savefig(f"charts/{fname}.png", dpi=110); plt.close()
for c in ["Contract", "InternetService", "PaymentMethod", "SeniorCitizen", "TechSupport", "OnlineSecurity", "PaperlessBilling"]:
    rate_chart(c, "churn_by_" + c.lower())
fig, ax = plt.subplots(1, 3, figsize=(12, 3.6))
for a, c in zip(ax, ["tenure", "MonthlyCharges", "TotalCharges"]):
    sns.histplot(data=df, x=c, hue="Churn", bins=30, ax=a)
plt.tight_layout(); plt.savefig("charts/numeric_distributions.png", dpi=110); plt.close()
pv = df.pivot_table(index="Contract", columns="InternetService", values="ChurnFlag", aggfunc="mean")*100
sns.heatmap(pv, annot=True, fmt=".1f", cmap="Reds"); plt.title("Churn % Contract vs Internet")
plt.tight_layout(); plt.savefig("charts/heatmap_contract_internet.png", dpi=110); plt.close()

# ---------- Modelling ----------
X = df.drop(columns=["customerID", "Churn", "ChurnFlag"])
num = ["tenure", "MonthlyCharges", "TotalCharges"]
cat = [c for c in X.columns if c not in num]
def pre(scale):
    return ColumnTransformer([("num", StandardScaler() if scale else "passthrough", num),
                              ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cat)])
lr = Pipeline([("pre", pre(True)), ("m", LogisticRegression(max_iter=3000, class_weight="balanced"))])
rf = Pipeline([("pre", pre(False)), ("m", RandomForestClassifier(n_estimators=300, min_samples_leaf=3,
               class_weight="balanced", random_state=42, n_jobs=-1))])
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
cv = StratifiedKFold(5, shuffle=True, random_state=42)
metrics = {}
plt.figure(figsize=(5.5, 4.5))
for name, mdl in [("Logistic Regression", lr), ("Random Forest", rf)]:
    mdl.fit(Xtr, ytr)
    pred, prob = mdl.predict(Xte), mdl.predict_proba(Xte)[:, 1]
    metrics[name] = dict(accuracy=round(accuracy_score(yte, pred)*100, 2), precision=round(precision_score(yte, pred)*100, 2),
        recall=round(recall_score(yte, pred)*100, 2), f1=round(f1_score(yte, pred)*100, 2), auc=round(roc_auc_score(yte, prob), 3),
        cv_auc=round(cross_val_score(mdl, X, y, cv=cv, scoring="roc_auc").mean(), 3),
        confusion=confusion_matrix(yte, pred).tolist())
    f, t, _ = roc_curve(yte, prob); plt.plot(f, t, label=f"{name} (AUC {metrics[name]['auc']})")
    print(name, metrics[name])
plt.plot([0, 1], [0, 1], "k--"); plt.legend(); plt.xlabel("False positive rate"); plt.ylabel("True positive rate")
plt.title("ROC curves"); plt.tight_layout(); plt.savefig("charts/roc_curves.png", dpi=110); plt.close()

names = rf.named_steps["pre"].get_feature_names_out()
imp = pd.Series(rf.named_steps["m"].feature_importances_, index=names).sort_values(ascending=False)
imp.head(10)[::-1].plot(kind="barh", figsize=(7, 4), color="#2E75B6"); plt.title("Top 10 features (Random Forest)")
plt.tight_layout(); plt.savefig("charts/feature_importance.png", dpi=110); plt.close()

# ---------- Save ----------
# Final deployed model: both fit on ALL clean data
lr.fit(X, y); rf.fit(X, y)
joblib.dump(lr, "models/logistic_regression.joblib", compress=3); joblib.dump(rf, "models/random_forest.joblib", compress=3)
json.dump({"sklearn": sklearn.__version__}, open("models/meta.json", "w"))
json.dump(metrics, open("models/metrics.json", "w"), indent=2, default=float)
imp.head(10).round(4).to_csv("models/top_features.csv")

# Export logistic regression for the browser app
p = lr.named_steps["pre"]; m = lr.named_steps["m"]
sc = p.named_transformers_["num"]; enc = p.named_transformers_["cat"]
feats = []
for i, c in enumerate(num):
    feats.append(dict(type="num", name=c, mean=float(sc.mean_[i]), scale=float(sc.scale_[i]), coef=float(m.coef_[0][i])))
k = len(num)
for c, cats in zip(cat, enc.categories_):
    levels = []
    for j, lv in enumerate(cats):
        levels.append(dict(level=str(lv), coef=0.0 if j == 0 else float(m.coef_[0][k])))
        if j: k += 1
    feats.append(dict(type="cat", name=c, levels=levels))
assert k == m.coef_.shape[1]
web = dict(intercept=float(m.intercept_[0]), features=feats, metrics=metrics, churn_rate=round(overall, 2), rows=len(df))
# self-check: JS-style computation must equal sklearn
import math
def js_prob(row):
    z = web["intercept"]
    for f in feats:
        if f["type"] == "num": z += (row[f["name"]]-f["mean"])/f["scale"]*f["coef"]
        else: z += next(l["coef"] for l in f["levels"] if l["level"] == row[f["name"]])
    return 1/(1+math.exp(-z))
sample = X.sample(200, random_state=1)
err = max(abs(js_prob(r)-p_) for (_, r), p_ in zip(sample.iterrows(), lr.predict_proba(sample)[:, 1]))
print("Max export error vs sklearn:", err); assert err < 1e-9
json.dump(web, open("models/web_model.json", "w"))
print("Done.")
