# How to run and how it works

## Requirements
Python 3.9 or newer. Internet is needed only once, to install libraries.

## Fastest way
- Windows: double-click `run_app.bat`
- Mac/Linux: run `bash run_app.sh`
Your browser opens at http://localhost:8501.

## Manual steps
1. Unzip the project and open a terminal inside the folder.
2. `pip install -r requirements.txt`
3. `python train.py`      (optional; about 1 minute; the app also trains itself automatically if the saved models do not match your scikit-learn version)
4. `python test_project.py`   (optional check; should print ALL TESTS PASSED)
5. `streamlit run app.py`

## How it works
1. `train.py` loads `data/Telco-Customer-Churn.csv` (7,043 rows), converts TotalCharges to numbers, drops 11 blank rows (7,032 remain), and saves EDA charts.
2. It one-hot encodes categories, scales numbers, and trains Logistic Regression and Random Forest on an 80/20 stratified split (random_state 42, class_weight balanced). Metrics go to `models/metrics.json`.
3. Final models are re-fit on all clean data and saved with joblib.
4. `app.py` loads the models:
   - Predict: you enter one customer; both models give a churn probability; the average sets HIGH (65%+), MEDIUM (35-65%) or LOW; tips follow your report's recommendations.
   - Insights: live EDA charts and model metrics computed from the dataset.
   - Batch: upload a CSV (or pick a demo file); every row is scored and sorted by risk; download the result. If a Churn column exists, a match check is shown.
5. `build_web.py` exports the logistic regression to `churn_app.html`, a standalone browser app.

## Demo files
- `demo_customers.csv`: 60 customers without the Churn label.
- `demo_customers_with_churn.csv`: same 60 with the real label.
Required CSV columns: gender, SeniorCitizen, Partner, Dependents, tenure, PhoneService, MultipleLines, InternetService, OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, StreamingMovies, Contract, PaperlessBilling, PaymentMethod, MonthlyCharges (TotalCharges optional; customerID optional).

## Troubleshooting
- First start takes about a minute if the app has to retrain; wait for the spinner.
- "Could not start the app": run `python train.py`, then restart.
- "Missing column(s)": the message names them; fix the header.
- Port busy: `streamlit run app.py --server.port 8502`.
