@echo off
REM One-click run (Windows): installs libraries, then starts the app (it trains itself if needed)
cd /d "%~dp0"
set PY=python
where python >nul 2>nul || set PY=py
if not exist "%USERPROFILE%\.streamlit" mkdir "%USERPROFILE%\.streamlit"
if not exist "%USERPROFILE%\.streamlit\credentials.toml" (echo [general]> "%USERPROFILE%\.streamlit\credentials.toml" & echo email = "">> "%USERPROFILE%\.streamlit\credentials.toml")
%PY% -m pip install -r requirements.txt
%PY% -m streamlit run app.py
pause
