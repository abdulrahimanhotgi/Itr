"""Shared helpers for the Streamlit app and tests."""
import os, sys, json, subprocess
import numpy as np, pandas as pd, joblib
from scipy import sparse

os.chdir(os.path.dirname(os.path.abspath(__file__)))
ADDONS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies"]
FILES = ["models/logistic_regression.joblib", "models/random_forest.joblib", "models/metrics.json", "models/meta.json"]

def level(p):
    return "HIGH" if p >= .65 else "MEDIUM" if p >= .35 else "LOW"

def models_ok():
    """True when saved models exist and were trained with the installed scikit-learn."""
    try:
        import sklearn
        return all(os.path.exists(f) for f in FILES) and json.load(open(FILES[3])).get("sklearn") == sklearn.__version__
    except Exception:
        return False

def ensure_models():
    """Train automatically if models are missing or incompatible with this computer's scikit-learn."""
    if models_ok():
        return
    r = subprocess.run([sys.executable, "train.py"], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("Training failed:\n" + (r.stderr or r.stdout)[-900:])

def load_models():
    return joblib.load(FILES[0]), joblib.load(FILES[1]), json.load(open(FILES[2]))

def clean_frame(d):
    d = d.copy()
    d["TotalCharges"] = pd.to_numeric(d["TotalCharges"], errors="coerce")
    d = d.dropna(subset=["TotalCharges"]).copy()
    d["SeniorCitizen"] = d["SeniorCitizen"].map({0: "No", 1: "Yes"})
    d["y"] = (d["Churn"] == "Yes").astype(int)
    return d

def load_data():
    return clean_frame(pd.read_csv("data/Telco-Customer-Churn.csv"))

def prepare(df, lr):
    """Make an uploaded table match the training format.
    Returns (X, ok_mask, error_message, problems) where problems is a list of readable notes."""
    cols = list(lr.feature_names_in_)
    cats = dict(zip([c for c in cols if c not in ("tenure", "MonthlyCharges", "TotalCharges")],
                    lr.named_steps["pre"].named_transformers_["cat"].categories_))
    df = df.copy(); df.columns = [str(c).strip() for c in df.columns]
    missing = [c for c in cols if c not in df.columns and c != "TotalCharges"]
    if missing:
        return None, None, "Missing column(s): " + ", ".join(missing), []
    for c in ("tenure", "MonthlyCharges"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    tc = pd.to_numeric(df["TotalCharges"], errors="coerce") if "TotalCharges" in df else pd.Series(np.nan, index=df.index)
    df["TotalCharges"] = tc.fillna(df["tenure"] * df["MonthlyCharges"])
    for c in cats:
        s = df[c]
        s = s.where(s.isna(), s.astype(str).str.strip()).astype(object)
        if c == "SeniorCitizen":
            s = s.replace({"0": "No", "1": "Yes", "0.0": "No", "1.0": "Yes", 0: "No", 1: "Yes"})
        df[c] = s.replace({"": np.nan})
    X = df[cols]
    ok = ~X.isna().any(axis=1) & (df["tenure"] >= 0) & (df["MonthlyCharges"] >= 0)
    notes = []
    for c, allowed in cats.items():
        bad = ok & ~X[c].isin(list(allowed))
        if bad.any():
            notes.append(f"{int(bad.sum())} row(s) have an unknown value in '{c}' (allowed: {', '.join(map(str, allowed))})")
            ok &= ~bad
    if not ok.any():
        return None, None, "No valid rows found. " + " ".join(notes), []
    return X, ok, None, notes

def _dense(t):
    return t.toarray() if sparse.issparse(t) else np.asarray(t)

def baseline_mean(lr, X_all):
    return _dense(lr.named_steps["pre"].transform(X_all)).mean(axis=0)

def explain(lr, row, mean):
    """Per-feature push on churn risk (log-odds) compared with the average customer."""
    pre, m = lr.named_steps["pre"], lr.named_steps["m"]
    cols = list(lr.feature_names_in_)
    contrib = (_dense(pre.transform(row))[0] - mean) * m.coef_[0]
    out = {}
    for n, v in zip(pre.get_feature_names_out(), contrib):
        n = n.split("__", 1)[1]
        col = next((k for k in cols if n == k or n.startswith(k + "_")), n)
        out[col] = out.get(col, 0.0) + float(v)
    res = []
    for col, v in out.items():
        val = row[col].iloc[0]
        val = f"{val:.0f}" if isinstance(val, (int, float, np.integer, np.floating)) else val
        res.append((f"{col}: {val}", v))
    return sorted(res, key=lambda x: -x[1])
