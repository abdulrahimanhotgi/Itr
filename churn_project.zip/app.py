"""Customer Churn Predictor (Streamlit).  Run:  streamlit run app.py"""
import os, pandas as pd, streamlit as st
import churn_utils as U

st.set_page_config(page_title="Customer Churn Predictor", page_icon="📉", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""<style>
.block-container{padding-top:1.2rem;padding-bottom:3rem;max-width:1150px}
.riskcard{border:1px solid rgba(128,128,128,.35);border-radius:14px;padding:16px 18px;margin:6px 0 12px}
.riskcard .pct{font-size:2.6rem;font-weight:700;line-height:1.1}
.riskcard .badge{display:inline-block;color:#fff;border-radius:99px;padding:2px 12px;font-weight:600;margin-left:10px;font-size:.9rem;vertical-align:middle}
.bar{height:14px;border-radius:7px;background:rgba(128,128,128,.25);overflow:hidden;margin-top:10px}
.bar i{display:block;height:100%}
@media (max-width:640px){.riskcard .pct{font-size:2.1rem}.block-container{padding-left:.8rem;padding-right:.8rem}}
</style>""", unsafe_allow_html=True)

try:
    if not U.models_ok():
        with st.spinner("First run: training the models (about 1 minute)..."):
            U.ensure_models()
    lr, rf, metrics = U.load_models()
    data = U.load_data()
except Exception as e:
    st.error(f"Could not start the app: {e}")
    st.info("Fix: open a terminal in the project folder and run `python train.py`, then restart the app.")
    st.stop()

COLS = list(lr.feature_names_in_)
@st.cache_resource
def _mean():
    X, ok, err, _ = U.prepare(data.drop(columns=["y"]), lr)
    return U.baseline_mean(lr, X[ok])
BASE = _mean()
COLOR = {"HIGH": "#c0392b", "MEDIUM": "#d98a00", "LOW": "#2a8c5a"}

with st.sidebar:
    st.header("How to use")
    st.write("**Predict:** set one customer's details and read the churn risk.\n\n"
             "**Insights:** see what the data says about why customers leave.\n\n"
             "**Batch:** score a whole CSV file and download the result.")
    st.caption("Risk levels: HIGH 65%+, MEDIUM 35-65%, LOW below 35%. Scores come from class-balanced models, so use the level to rank customers.")

st.title("Customer Churn Predictor")
st.caption(f"Trained on {len(data):,} Telco customers. {data.y.mean()*100:.2f}% churned.")
t1, t2, t3 = st.tabs(["Predict", "Insights", "Batch scoring"])

DEFAULT = dict(k_tenure=12, k_MonthlyCharges=70.0, k_Contract="Month-to-month", k_InternetService="Fiber optic",
               k_PaymentMethod="Electronic check", k_PaperlessBilling="Yes", k_PhoneService="Yes", k_MultipleLines="No",
               k_gender="Female", k_SeniorCitizen="No", k_Partner="No", k_Dependents="No", **{f"k_{a}": "No" for a in U.ADDONS})
HIGH = dict(DEFAULT, k_tenure=2, k_MonthlyCharges=85.0)
LOW = dict(DEFAULT, k_tenure=60, k_MonthlyCharges=55.0, k_Contract="Two year", k_InternetService="DSL",
           k_PaymentMethod="Credit card (automatic)", k_PaperlessBilling="No", k_Partner="Yes", k_Dependents="Yes",
           **{f"k_{a}": "Yes" for a in U.ADDONS})
for k, v in DEFAULT.items():
    st.session_state.setdefault(k, v)
def preset(d):
    for k, v in d.items():
        st.session_state[k] = v

with t1:
    b = st.columns(3)
    b[0].button("Load high-risk example", on_click=preset, args=(HIGH,), use_container_width=False)
    b[1].button("Load low-risk example", on_click=preset, args=(LOW,))
    b[2].button("Reset", on_click=preset, args=(DEFAULT,))
    c = st.columns(3); inp = {}
    inp["tenure"] = c[0].slider("Tenure (months)", 0, 72, key="k_tenure")
    inp["MonthlyCharges"] = c[1].slider("Monthly charges", 18.0, 120.0, step=0.5, key="k_MonthlyCharges")
    inp["Contract"] = c[2].selectbox("Contract", ["Month-to-month", "One year", "Two year"], key="k_Contract")
    inp["InternetService"] = c[0].selectbox("Internet service", ["Fiber optic", "DSL", "No"], key="k_InternetService")
    inp["PaymentMethod"] = c[1].selectbox("Payment method", ["Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"], key="k_PaymentMethod")
    inp["PaperlessBilling"] = c[2].selectbox("Paperless billing", ["Yes", "No"], key="k_PaperlessBilling")
    has_net = inp["InternetService"] != "No"
    for i, col in enumerate(U.ADDONS):
        inp[col] = c[i % 3].selectbox(col, ["No", "Yes"], key=f"k_{col}") if has_net else "No internet service"
    if not has_net: st.caption("Add-on services are not available without internet service.")
    inp["PhoneService"] = c[0].selectbox("Phone service", ["Yes", "No"], key="k_PhoneService")
    inp["MultipleLines"] = c[1].selectbox("Multiple lines", ["No", "Yes"], key="k_MultipleLines") if inp["PhoneService"] == "Yes" else "No phone service"
    inp["gender"] = c[2].selectbox("Gender", ["Female", "Male"], key="k_gender")
    inp["SeniorCitizen"] = c[0].selectbox("Senior citizen", ["No", "Yes"], key="k_SeniorCitizen")
    inp["Partner"] = c[1].selectbox("Partner", ["No", "Yes"], key="k_Partner")
    inp["Dependents"] = c[2].selectbox("Dependents", ["No", "Yes"], key="k_Dependents")
    inp["TotalCharges"] = inp["tenure"] * inp["MonthlyCharges"]
    row = pd.DataFrame([inp])[COLS]
    p1, p2 = float(lr.predict_proba(row)[0, 1]), float(rf.predict_proba(row)[0, 1]); avg = (p1 + p2) / 2
    lv = U.level(avg)
    st.markdown(f'<div class="riskcard"><span class="pct">{avg:.0%}</span><span class="badge" style="background:{COLOR[lv]}">{lv} RISK</span>'
                f'<div class="bar"><i style="width:{avg*100:.0f}%;background:{COLOR[lv]}"></i></div></div>', unsafe_allow_html=True)
    m = st.columns(2); m[0].metric("Logistic Regression", f"{p1:.0%}"); m[1].metric("Random Forest", f"{p2:.0%}")
    contrib = U.explain(lr, row, BASE)
    up = [x for x in contrib if x[1] > 0.12][:4]; dn = [x for x in contrib[::-1] if x[1] < -0.12][:3]
    l, r = st.columns(2)
    with l:
        st.subheader("Raises risk")
        for t, _ in up: st.write(f"- {t}")
        if not up: st.write("Nothing strong.")
    with r:
        st.subheader("Lowers risk")
        for t, _ in dn: st.write(f"- {t}")
        if not dn: st.write("Nothing strong.")
    tips = []
    if inp["Contract"] == "Month-to-month": tips.append("Offer a discount to move to a one- or two-year contract.")
    if inp["tenure"] <= 12: tips.append("Run onboarding check-ins at 30, 90 and 180 days.")
    if inp["PaymentMethod"] == "Electronic check": tips.append("Offer cashback for automatic payment.")
    if has_net and "No" in (inp["TechSupport"], inp["OnlineSecurity"]): tips.append("Bundle tech support and online security free for 3 months.")
    if inp["InternetService"] == "Fiber optic" and inp["MonthlyCharges"] > 85: tips.append("Review fiber plan pricing and send bill alerts.")
    if inp["SeniorCitizen"] == "Yes": tips.append("Provide assisted setup and helpline support.")
    st.subheader("Suggested actions")
    for t in tips or ["Low risk: keep service quality steady and reward loyalty."]: st.write("- " + t)

with t2:
    k = st.columns(4); k[0].metric("Customers", f"{len(data):,}"); k[1].metric("Churn rate", f"{data.y.mean()*100:.2f}%")
    k[2].metric("Churned", f"{int(data.y.sum()):,}"); k[3].metric("Monthly revenue lost", f"{data[data.y == 1].MonthlyCharges.sum():,.0f}")
    left, right = st.columns(2)
    for i, col in enumerate(["Contract", "InternetService", "PaymentMethod", "TechSupport", "OnlineSecurity", "PaperlessBilling"]):
        with (left if i % 2 == 0 else right):
            st.subheader(f"Churn % by {col}")
            st.bar_chart(data.groupby(col)["y"].mean().mul(100).sort_values(ascending=False))
    with left:
        st.subheader("Churn % by tenure (months)")
        g = pd.cut(data.tenure, [0, 12, 24, 48, 60, 72], labels=["0-12", "13-24", "25-48", "49-60", "61-72"])
        st.bar_chart(data.groupby(g, observed=True)["y"].mean().mul(100))
    st.subheader("Model performance (20% test set)")
    st.dataframe(pd.DataFrame(metrics).T.drop(columns="confusion"))
    for f in ["feature_importance", "roc_curves", "heatmap_contract_internet"]:
        if os.path.exists(f"charts/{f}.png"): st.image(f"charts/{f}.png")

with t3:
    st.write("Score many customers at once. Use the demo files or upload your own CSV with the Telco columns.")
    src = st.radio("Source", ["Demo: 60 customers", "Demo: 60 customers with Churn column", "Upload my CSV"], horizontal=True)
    df = None
    try:
        if src == "Upload my CSV":
            up = st.file_uploader("CSV file", type="csv")
            if up: df = pd.read_csv(up)
        else:
            df = pd.read_csv("demo_customers.csv" if src == "Demo: 60 customers" else "demo_customers_with_churn.csv")
    except Exception as e:
        st.error(f"Could not read that file as CSV: {e}")
    if df is not None:
        X, ok, err, notes = U.prepare(df, lr)
        if err: st.error(err)
        else:
            out = df.loc[ok].copy(); Xo = X[ok]
            out["risk_lr"] = lr.predict_proba(Xo)[:, 1].round(3); out["risk_rf"] = rf.predict_proba(Xo)[:, 1].round(3)
            out["risk"] = ((out.risk_lr + out.risk_rf) / 2).round(3); out["level"] = out.risk.map(U.level)
            out = out.sort_values("risk", ascending=False)
            first = [c for c in ["customerID", "risk", "level"] if c in out]
            out = out[first + [c for c in out.columns if c not in first]]
            m = st.columns(4); m[0].metric("Scored", len(out))
            for j, L in enumerate(["HIGH", "MEDIUM", "LOW"]): m[j + 1].metric(L.title() + " risk", int((out.level == L).sum()))
            if (~ok).any(): st.warning(f"{int((~ok).sum())} row(s) skipped (blank or invalid values).")
            for n in notes: st.warning(n)
            st.dataframe(out, column_config={"risk": st.column_config.ProgressColumn("risk", min_value=0.0, max_value=1.0, format="%.2f")})
            st.download_button("Download scored CSV", out.to_csv(index=False), "scored_customers.csv", "text/csv")
            if "Churn" in out:
                pred = (out.risk >= .5).map({True: "Yes", False: "No"})
                st.info(f"Check against the actual Churn column: {(pred == out.Churn.astype(str).str.strip()).mean():.0%} match. "
                        "The demo customers were part of the training data, so this is optimistic.")
