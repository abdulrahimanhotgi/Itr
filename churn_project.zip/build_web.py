"""Builds the self-contained browser app (churn_app.html) from the trained model + real EDA numbers."""
import json, pandas as pd
web = json.load(open("models/web_model.json"))
df = pd.read_csv("data/Telco-Customer-Churn.csv")
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce"); df = df.dropna(subset=["TotalCharges"])
df["SeniorCitizen"] = df["SeniorCitizen"].map({0: "No", 1: "Yes"}); df["y"] = (df["Churn"] == "Yes").astype(int)
for f in web["features"]:
    if f["type"] == "cat":
        vc = df[f["name"]].value_counts(normalize=True)
        for l in f["levels"]: l["freq"] = round(float(vc.get(l["level"], 0)), 5)
df["Tenure"] = pd.cut(df["tenure"], [0, 12, 24, 48, 60, 72], labels=["0-12 mo", "13-24 mo", "25-48 mo", "49-60 mo", "61-72 mo"])
eda = {}
for col in ["Contract", "InternetService", "PaymentMethod", "Tenure", "TechSupport", "OnlineSecurity", "SeniorCitizen", "PaperlessBilling"]:
    g = df.groupby(col, observed=True)["y"].agg(["mean", "size"])
    eda[col] = [[str(i), round(r["mean"]*100, 1), int(r["size"])] for i, r in g.sort_values("mean", ascending=False).iterrows()]
web["eda"] = eda
web["lost_revenue"] = round(float(df[df.y == 1]["MonthlyCharges"].sum()), 0)
web["churned"] = int(df.y.sum())
tmpl = open("web_template.html").read()
open("churn_app.html", "w").write(tmpl.replace("/*DATA*/null", json.dumps(web, separators=(",", ":"))))
print("built", len(open("churn_app.html").read())//1024, "KB")
