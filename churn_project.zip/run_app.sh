#!/usr/bin/env bash
# One-click run (Mac/Linux): installs libraries, then starts the app (it trains itself if needed)
set -e
cd "$(dirname "$0")"
mkdir -p "$HOME/.streamlit"
[ -f "$HOME/.streamlit/credentials.toml" ] || printf '[general]\nemail = ""\n' > "$HOME/.streamlit/credentials.toml"
python3 -m pip install -r requirements.txt
python3 -m streamlit run app.py
