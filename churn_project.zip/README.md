# Customer Churn Analysis (EDA + Insights + Prediction)

1. `pip install -r requirements.txt`
2. Keep `data/Telco-Customer-Churn.csv` in place (included).
3. `python train.py`   -> cleans data, saves EDA charts to `charts/`, trains Logistic Regression + Random Forest, saves `models/`.
4. `streamlit run app.py`   -> interactive Predict / Insights / Batch app.
5. `python build_web.py`   -> rebuilds the standalone browser app `churn_app.html` from the trained model.
