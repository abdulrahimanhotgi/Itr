"""Smoke tests: python test_project.py"""
import json, pandas as pd, churn_utils as U
from streamlit.testing.v1 import AppTest
assert U.models_ok(), "models missing: run python train.py"
lr, rf, metrics = U.load_models()
assert metrics["Logistic Regression"]["auc"] > 0.8

# 1. data preparation edge cases
d = pd.read_csv("demo_customers.csv")
X, ok, err, notes = U.prepare(d, lr); assert err is None and ok.all() and len(X) == 60
d2 = d.copy(); d2["SeniorCitizen"] = d2["SeniorCitizen"].map({0: "No", 1: "Yes"}); d2["Contract"] = " " + d2["Contract"] + " "
d2["TotalCharges"] = ""; d2["tenure"] = d2["tenure"].astype(object); d2.loc[0, "tenure"] = "abc"; d2.loc[1, "Contract"] = "Weekly"
X, ok, err, notes = U.prepare(d2, lr); assert err is None and int(ok.sum()) == 58 and notes, (ok.sum(), notes)
assert U.prepare(d.drop(columns=["tenure"]), lr)[2].startswith("Missing")
print("data preparation: OK")

# 2. whole app, every tab and button
at = AppTest.from_file("app.py", default_timeout=120).run(); assert not at.exception, at.exception
assert len(at.tabs) == 3
def card(): return " ".join(m.value for m in at.markdown if "riskcard" in m.value)
btn = {b.label: b for b in at.button}
btn["Load high-risk example"].click().run(); assert not at.exception and "HIGH RISK" in card(), card()
btn = {b.label: b for b in at.button}; btn["Load low-risk example"].click().run(); assert not at.exception and "LOW RISK" in card(), card()
btn = {b.label: b for b in at.button}; btn["Reset"].click().run(); assert not at.exception
at.selectbox(key="k_InternetService").set_value("No").run(); assert not at.exception
at.radio[0].set_value("Demo: 60 customers with Churn column").run(); assert not at.exception, at.exception
at.radio[0].set_value("Demo: 60 customers").run(); assert not at.exception
print("app (predict, presets, no-internet, batch demos): OK")
print("ALL TESTS PASSED")
